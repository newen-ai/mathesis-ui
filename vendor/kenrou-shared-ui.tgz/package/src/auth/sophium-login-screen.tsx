"use client";

import {
  SharedBrandedLoginScreen,
  type SharedBrandedLoginScreenProps,
} from "./branded-login-screen";

type SophiumLoginScreenProps = {
  logoSrc?: string;
  logoAlt?: string;
  formProps: SharedBrandedLoginScreenProps["formProps"];
};

export function SophiumLoginScreen({
  logoSrc = "/sophium-logo.png",
  logoAlt = "Logo Sophium",
  formProps,
}: SophiumLoginScreenProps) {
  return (
    <SharedBrandedLoginScreen
      brandName="Sophium"
      logoSrc={logoSrc}
      logoAlt={logoAlt}
      mobileTagline="La primera comunidad intelectual verificada para mentes excepcionales."
      badgeLabel="Comunidad verificada"
      heroTitle="La primera comunidad intelectual verificada para mentes excepcionales."
      heroSubtitle="La red que conecta a los Miembros de Mensa."
      domainLabel="sophium.social"
      welcomeTitle="Bienvenido a Sophium"
      formProps={formProps}
      footer={{
        membershipPrompt: "¿Sos Miembro de Mensa y todavía no tenés cuenta en Sophium?",
        registerHref: "/registro",
        registerLabel: "Registrate acá →",
        nonMemberPrompt: "¿Todavía no sos Miembro de Mensa?",
        nonMemberHref: "https://mensa.org",
        nonMemberLabel: "Conocé más en mensa.org",
      }}
    />
  );
}
