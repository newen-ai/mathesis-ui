"use client";

import { SharedBrandedLoginScreen } from "./branded-login-screen";

export function MathesisLoginScreen({
  logoSrc = "/mathesis-logo.png",
  logoAlt = "Logo Mathesis",
  formProps,
}) {
  return (
    <SharedBrandedLoginScreen
      brandName="Mathesis"
      logoSrc={logoSrc}
      logoAlt={logoAlt}
      mobileTagline="La primera comunidad intelectual verificada para mentes excepcionales."
      badgeLabel="Comunidad verificada"
      heroTitle="La primera comunidad intelectual verificada para mentes excepcionales."
      heroSubtitle="La red que conecta a los Miembros de Mensa."
      domainLabel="mathesis.social"
      welcomeTitle="Bienvenido a Mathesis"
      formProps={formProps}
      footer={{
        membershipPrompt: "¿Sos Miembro de Mensa y todavía no tenés cuenta en Mathesis?",
        registerHref: "/registro",
        registerLabel: "Registrate acá →",
        nonMemberPrompt: "¿Todavía no sos Miembro de Mensa?",
        nonMemberHref: "https://mensa.org",
        nonMemberLabel: "Conocé más en mensa.org",
      }}
    />
  );
}
