"use client";

import { useState } from "react";

export function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function defaultFailureMessage(result) {
  if (typeof result?.message === "string" && result.message.trim().length > 0) {
    return result.message;
  }

  return "Could not sign in.";
}

export function SharedLoginForm({
  initialEmail = "",
  minPasswordLength = 8,
  normalizeEmail,
  validateEmail,
  login,
  onSuccess,
  onFailure,
  resolveFailureMessage,
  messages,
  forgotPasswordAction,
  enablePasswordToggle,
  classNames,
  styles,
  renderPasswordField
}) {
  const [email, setEmail] = useState(initialEmail);
  const [password, setPassword] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isPasswordVisible, setIsPasswordVisible] = useState(false);
  const [errors, setErrors] = useState({});

  const onSubmit = async (event) => {
    event.preventDefault();

    const normalizedEmail = normalizeEmail ? normalizeEmail(email) : email.trim().toLowerCase();
    const emailValidator = validateEmail ?? isValidEmail;

    const nextErrors = {};

    if (!normalizedEmail || !emailValidator(normalizedEmail)) {
      nextErrors.email = messages.invalidEmail;
    }

    if (!password || password.length < minPasswordLength) {
      nextErrors.password = messages.invalidPassword;
    }

    setErrors(nextErrors);

    if (Object.keys(nextErrors).length > 0) {
      return;
    }

    setIsSubmitting(true);

    try {
      const input = {
        email: normalizedEmail,
        password
      };
      const result = await login(input);

      if (!result.success) {
        if (onFailure) {
          const handled = await onFailure({ result, input });
          if (handled) {
            return;
          }
        }

        setErrors({
          credentials: resolveFailureMessage
            ? resolveFailureMessage(result)
            : defaultFailureMessage(result) || messages.genericError
        });

        return;
      }

      await onSuccess(input);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form className={classNames?.form} onSubmit={onSubmit} noValidate>
      <div className={classNames?.fieldGroup}>
        <label htmlFor="email" className={classNames?.label} style={styles?.label}>
          {messages.emailLabel}
        </label>
        <input
          id="email"
          type="email"
          autoComplete="email"
          inputMode="email"
          placeholder={messages.emailPlaceholder}
          value={email}
          onChange={(event) => setEmail(event.target.value)}
          aria-invalid={Boolean(errors.email)}
          aria-describedby={errors.email ? "shared-login-email-error" : undefined}
          className={classNames?.input}
          style={styles?.input}
        />
        {errors.email ? (
          <p id="shared-login-email-error" className={classNames?.errorText}>
            {errors.email}
          </p>
        ) : null}
      </div>

      <div className={classNames?.fieldGroup}>
        <label htmlFor="password" className={classNames?.label} style={styles?.label}>
          {messages.passwordLabel}
        </label>
        {renderPasswordField ? (
          renderPasswordField({
            id: "password",
            value: password,
            onChange: (value) => setPassword(value),
            className: classNames?.input,
            placeholder: messages.passwordPlaceholder,
            autoComplete: "current-password",
            hasError: Boolean(errors.password),
            ariaDescribedBy: errors.password ? "shared-login-password-error" : undefined
          })
        ) : (
          <div className={classNames?.passwordInputWrapper ?? "relative"}>
            <input
              id="password"
              type={enablePasswordToggle && isPasswordVisible ? "text" : "password"}
              autoComplete="current-password"
              placeholder={messages.passwordPlaceholder}
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              aria-invalid={Boolean(errors.password)}
              aria-describedby={errors.password ? "shared-login-password-error" : undefined}
              className={classNames?.passwordInput ?? classNames?.input}
              style={styles?.input}
            />
            {enablePasswordToggle ? (
              <button
                type="button"
                onClick={() => setIsPasswordVisible((visible) => !visible)}
                className={classNames?.passwordToggleButton ?? "absolute right-3 top-1/2 -translate-y-1/2 text-xs"}
                aria-label={isPasswordVisible ? "Hide password" : "Show password"}
              >
                {isPasswordVisible ? "Ocultar" : "Mostrar"}
              </button>
            ) : null}
          </div>
        )}
        {errors.password ? (
          <p id="shared-login-password-error" className={classNames?.errorText}>
            {errors.password}
          </p>
        ) : null}
      </div>

      {errors.credentials ? (
        <p className={classNames?.credentialsError} style={styles?.credentialsError}>
          {errors.credentials}
        </p>
      ) : null}

      <button
        type="submit"
        disabled={isSubmitting}
        className={classNames?.submitButton}
        style={styles?.submitButton}
      >
        {isSubmitting ? messages.submittingLabel : messages.submitLabel}
      </button>

      {messages.forgotPasswordLabel && forgotPasswordAction ? (
        <button
          type="button"
          onClick={forgotPasswordAction}
          className={classNames?.forgotPasswordButton}
          style={styles?.forgotPasswordButton}
        >
          {messages.forgotPasswordLabel}
        </button>
      ) : null}
    </form>
  );
}
