"use client";

import { SharedBrandedLoginScreen } from "./branded-login-screen";

export function SophiumLoginScreen({
  logoSrc = "/sophium-logo.png",
  logoAlt = "Logo Sophium",
  formProps,
}) {
  return (
    <SharedBrandedLoginScreen
      brandName="Sophium"
      logoSrc={logoSrc}
      logoAlt={logoAlt}
      mobileTagline="La primera comunidad intelectual verificada para mentes excepcionales."
      badgeLabel="Comunidad verificada"
      heroTitle="La primera comunidad intelectual verificada para mentes excepcionales."
      heroSubtitle="La red que conecta a personas con alto IQ."
      domainLabel="sophium.social"
      welcomeTitle="Bienvenido a Sophium"
      formProps={formProps}
      footer={{
        membershipPrompt: "¿No tenés cuenta en Sophium?",
        registerHref: "/registro",
        registerLabel: "Registrate acá →",
        nonMemberPrompt: "¿Todavía no sos Miembro de Mensa? Conocé más en",
        nonMemberHref: "https://mensa.org",
        nonMemberLabel: "mensa.org",
      }}
    />
  );
}
