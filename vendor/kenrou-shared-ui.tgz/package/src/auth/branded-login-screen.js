"use client";

import Link from "next/link";
import { SharedLoginForm } from "./login-form";

export function SharedBrandedLoginScreen({
  brandName,
  logoSrc,
  logoAlt,
  mobileTagline,
  badgeLabel,
  heroTitle,
  heroSubtitle,
  domainLabel,
  welcomeTitle,
  welcomeDescription,
  formProps,
  footer
}) {
  const brandInitial = brandName.trim().charAt(0).toUpperCase() || "M";

  return (
    <main className="flex min-h-[calc(100dvh-2.5rem)] flex-col bg-white font-[family-name:Arial] md:min-h-[calc(100dvh-2.75rem)] lg:flex-row">
      <section className="flex flex-1 flex-col lg:flex-row">
        <div className="sophium-login-brand-panel px-6 pb-8 pt-9 text-center lg:flex lg:w-2/5 lg:shrink-0 lg:flex-col lg:justify-between lg:px-12 lg:py-14 lg:text-left">
          <div className="flex flex-col items-center lg:flex-row lg:items-center lg:gap-3">
            {logoSrc ? (
              <img
                src={logoSrc}
                alt={logoAlt ?? `${brandName} logo`}
                width={64}
                height={64}
                loading="eager"
                decoding="async"
                className="mx-auto h-16 w-16 lg:mx-0 lg:h-9 lg:w-9"
              />
            ) : (
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border-2 border-[#C9A84C] bg-[#0A2540] text-2xl font-bold text-[#FAF8F5] lg:mx-0 lg:h-9 lg:w-9 lg:text-base lg:text-[#FAF8F5]">
                {brandInitial}
              </div>
            )}
            <div className="sophium-login-brand-title mt-2 font-[family-name:Georgia] text-xl font-bold tracking-[0.1em] lg:mt-0 lg:text-xl">
              {brandName}
            </div>
          </div>

          <div className="mt-1.5 font-[family-name:Georgia] text-sm italic text-[#0A2540]/70 lg:hidden">
            {mobileTagline}
          </div>

          <div className="relative z-10 hidden lg:block">
            <div className="text-[0.62rem] font-bold uppercase tracking-[0.12em] text-[#C9A84C]/80">
              {badgeLabel}
            </div>
            <div className="mt-4 font-[family-name:Georgia] text-xl font-bold leading-snug text-[#FAF8F5]">
              {heroTitle}
            </div>
            <div className="mt-4 max-w-xs font-[family-name:Georgia] text-sm italic leading-relaxed text-[#FAF8F5]/70">
              {heroSubtitle}
            </div>
          </div>

          <div className="relative z-10 hidden text-[0.66rem] text-[#FAF8F5]/40 lg:block">{domainLabel}</div>
        </div>

        <div className="flex flex-1 flex-col px-6 pb-6 lg:justify-center lg:px-14 lg:py-14">
          <div className="w-full lg:mx-auto lg:max-w-[440px]">
            <div className="mb-6 hidden font-[family-name:Georgia] text-2xl font-bold text-[#0A2540] lg:block">
              {welcomeTitle}
            </div>

            {welcomeDescription ? (
              <p className="mb-6 text-sm" style={{ color: "var(--text-secondary)" }}>
                {welcomeDescription}
              </p>
            ) : null}

            <SharedLoginForm
              {...formProps}
              classNames={{
                form: "flex flex-col gap-4",
                fieldGroup: "flex flex-col gap-1.5",
                label: "text-xs font-bold tracking-wide text-[#0A2540]",
                passwordInputWrapper: "relative",
                passwordInput:
                  "w-full rounded-lg border-[1.5px] border-[#E8E5E0] bg-white px-3.5 py-2.5 pr-16 text-sm text-[#1A1A1A] outline-none transition focus:border-[#C9A84C]",
                input:
                  "rounded-lg border-[1.5px] border-[#E8E5E0] bg-white px-3.5 py-2.5 text-sm text-[#1A1A1A] outline-none transition focus:border-[#C9A84C]",
                errorText: "text-xs font-medium text-red-700",
                credentialsError:
                  "rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs font-semibold text-red-700",
                submitButton:
                  "mt-1 w-full rounded-full bg-[#C9A84C] px-6 py-3 text-sm font-bold text-[#1A1A1A] transition hover:bg-[#b8973f] disabled:cursor-not-allowed disabled:opacity-70",
                forgotPasswordButton: "text-center text-xs text-[#7A6435] transition hover:underline",
                passwordToggleButton:
                  "absolute right-3 top-1/2 -translate-y-1/2 text-xs font-semibold text-[#7A6435] hover:underline"
              }}
              enablePasswordToggle={true}
            />
          </div>

          {footer ? (
            <div className="mt-auto w-full pt-4 lg:mx-auto lg:mt-8 lg:max-w-[440px] lg:pt-0">
              <div className="border-t border-[#E8E5E0] pt-4 text-center text-xs leading-relaxed text-[#666666]">
                {footer.membershipPrompt}
                <br />
                <Link href={footer.registerHref} className="font-bold text-[#7A6435] hover:underline">
                  {footer.registerLabel}
                </Link>
                <div className="mt-2">
                  {footer.nonMemberPrompt}{" "}
                  <a
                    href={footer.nonMemberHref}
                    target="_blank"
                    rel="noreferrer"
                    className="text-[#7A6435] hover:underline"
                  >
                    {footer.nonMemberLabel}
                  </a>
                </div>
              </div>
            </div>
          ) : null}
        </div>
      </section>
      <style jsx>{`
        .sophium-login-brand-panel {
          background: transparent;
        }

        .sophium-login-brand-title {
          color: #0a2540;
        }

        @media (min-width: 1024px) {
          .sophium-login-brand-panel {
            background: #0a2540;
          }

          .sophium-login-brand-title {
            color: #faf8f5;
          }
        }
      `}</style>
    </main>
  );
}
