import { execFileSync } from "node:child_process";
import { copyFileSync, mkdirSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const scriptDir = dirname(fileURLToPath(import.meta.url));
const sharedUiRoot = resolve(scriptDir, "..");

const rawOutput = execFileSync("npm", ["pack"], {
  cwd: sharedUiRoot,
  encoding: "utf8",
});

const packedFileName = rawOutput
  .split("\n")
  .map((line) => line.trim())
  .filter(Boolean)
  .at(-1);

if (!packedFileName) {
  throw new Error("Could not determine tarball name from npm pack output.");
}

const packedFilePath = resolve(sharedUiRoot, packedFileName);
const targets = [
  resolve(sharedUiRoot, "../mathesis-admin/vendor/kenrou-shared-ui.tgz"),
  resolve(sharedUiRoot, "../mathesis-ui/vendor/kenrou-shared-ui.tgz"),
];

for (const targetPath of targets) {
  mkdirSync(dirname(targetPath), { recursive: true });
  copyFileSync(packedFilePath, targetPath);
  console.log(`Copied ${packedFileName} -> ${targetPath}`);
}
